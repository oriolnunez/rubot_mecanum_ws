void bcm_host(void) {
}
